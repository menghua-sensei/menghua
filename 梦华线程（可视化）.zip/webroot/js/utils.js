// 工具函数

// 全局配置
const CONFIG = {
    CONFIG_FILE_PATH: '/data/adb/modules/AppOpt/applist.conf',
    AUTO_SAVE: false,
    APP_NAME_TOOL: '/data/adb/modules/AppOpt/webroot/tool/appinfo',
    APPLIST_CACHE_FILE: '/data/adb/modules/AppOpt/webroot/applist.txt'
};

// 应用范围设置
const APP_SCOPE_STORAGE_KEY = 'appopt_app_scope';
const APP_SCOPE_OPTIONS = {
    user: { flag: '-3', name: '用户应用' },
    system: { flag: '-s', name: '系统应用' },
    all: { flag: '-a', name: '所有应用' }
};

/**
 * 生成唯一ID
 * @returns {string} 唯一ID
 */
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

/**
 * 显示加载动画
 */
function showLoading() {
    document.querySelector('.loading-overlay').classList.add('active');
}

/**
 * 隐藏加载动画
 */
function hideLoading() {
    document.querySelector('.loading-overlay').classList.remove('active');
}

/**
 * 显示提示信息
 * @param {string} message - 提示内容
 * @param {string} type - 提示类型：info, success, error, warning
 * @param {number} duration - 显示时长(毫秒)
 */
function showToast(message, type = 'info', duration = 1000) {
    const container = document.querySelector('.toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    // 处理长文本
    let displayMessage = message;
    const maxToastLength = 50; // 最大显示长度

    if (message.length > maxToastLength) {
        // 检查是否有引号包裹的内容
        if (message.includes('"')) {
            const parts = message.split('"');
            if (parts.length >= 3) {
                // 提取引号内的内容
                const quotedContent = parts[1];

                // 如果引号内容很长，进行截断
                if (quotedContent.length > 25) {
                    displayMessage = parts[0] + '"' + quotedContent.substring(0, 22) + '..."' + (parts[2].length > 10 ? parts[2].substring(0, 10) + '...' : parts[2]);
                } else {
                    // 如果引号内容不长，但整体消息太长
                    displayMessage = parts[0] + '"' + quotedContent + '"' + (parts[2].length > 15 ? parts[2].substring(0, 12) + '...' : parts[2]);
                }
            } else {
                displayMessage = message.substring(0, maxToastLength) + '...';
            }
        } else {
            displayMessage = message.substring(0, maxToastLength) + '...';
        }
    }

    // 添加图标
    let iconName = '';
    switch (type) {
        case 'success': iconName = 'check_circle'; break;
        case 'error': iconName = 'error'; break;
        case 'warning': iconName = 'warning'; break;
        default: iconName = 'info'; break;
    }

    toast.innerHTML = `
        <i class="material-icons-round">${iconName}</i>
        <span title="${message}">${displayMessage}</span>
    `;

    container.appendChild(toast);

    // 自动移除提示
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(100px)';
        setTimeout(() => {
            container.removeChild(toast);
        }, 300);
    }, duration);
}

/**
 * 执行命令
 * @param {string} command - 要执行的命令
 * @returns {Promise<string>} 命令执行结果
 */
async function execCommand(command) {
    const callbackName = `exec_callback_${Date.now()}`;

    return new Promise((resolve, reject) => {
        window[callbackName] = (errno, stdout, stderr) => {
            delete window[callbackName];
            errno === 0 ? resolve(stdout) : reject(stderr || "执行错误");
        };

        try {
            if (typeof ksuApi !== 'undefined' && ksuApi && ksuApi.exec) {
                ksuApi.exec(command, "{}", callbackName);
            } else if (typeof ksu !== 'undefined' && ksu && ksu.exec) {
                // 兼容性处理
                ksu.exec(command, "{}", callbackName);
            } else {
                // 无法访问API时
                console.error("KernelSU API不可用");
                showToast("KernelSU API不可用，请检查权限或刷新页面", "error");
                reject("KernelSU API不可用");
            }
        } catch (error) {
            console.error("执行命令失败:", error);
            showToast("执行命令失败: " + error.message, "error");
            reject(error);
        }
    });
}

/**
 * 验证CPU核心范围格式
 * @param {string} input - 核心范围字符串，例如 "0-3,5-7"
 * @returns {boolean} 格式是否有效
 */
function validateCoreInput(input) {
    if (!input) return false;

    // 允许的格式: "0-3", "0,1,2,3", "0-2,4,6-7"
    const pattern = /^(\d+(-\d+)?)(,\d+(-\d+)?)*$/;
    return pattern.test(input);
}

/**
 * 初始化主题设置
 * 根据系统主题或用户偏好设置应用主题
 */
function initTheme() {
    // 从本地存储获取主题偏好
    const savedTheme = localStorage.getItem('theme');

    if (savedTheme) {
        // 应用已保存的主题偏好
        applyTheme(savedTheme);
    } else {
        // 跟随系统主题
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        applyTheme(prefersDark ? 'dark' : 'light');
    }

    // 监听系统主题变化
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        // 如果未设置明确的主题偏好，则跟随系统变化
        if (!localStorage.getItem('theme')) {
            applyTheme(e.matches ? 'dark' : 'light');
        }
    });
}

/**
 * 应用主题
 * @param {string} theme - 主题名称：'light' 或 'dark'
 */
function applyTheme(theme) {
    const body = document.body;
    const themeToggle = document.getElementById('theme-toggle');

    if (theme === 'dark') {
        body.classList.add('dark-mode');
        if (themeToggle) themeToggle.innerHTML = '<i class="material-icons-round">light_mode</i>';
    } else {
        body.classList.remove('dark-mode');
        if (themeToggle) themeToggle.innerHTML = '<i class="material-icons-round">dark_mode</i>';
    }
}

/**
 * 切换主题
 */
function toggleTheme() {
    const isDarkMode = document.body.classList.contains('dark-mode');
    const newTheme = isDarkMode ? 'light' : 'dark';

    // 保存用户主题偏好
    localStorage.setItem('theme', newTheme);

    // 应用新主题
    applyTheme(newTheme);
}

/**
 * 检查是否为空对象
 * @param {Object} obj - 要检查的对象
 * @returns {boolean} 是否为空对象
 */
function isEmptyObject(obj) {
    return obj && Object.keys(obj).length === 0 && obj.constructor === Object;
}

/**
 * 处理文本溢出
 * @param {HTMLElement} element - DOM元素
 * @param {number} maxLength - 最大长度
 */
function handleTextOverflow(element, maxLength) {
    if (element.textContent.length > maxLength) {
        element.title = element.textContent;
        element.textContent = element.textContent.substring(0, maxLength) + '...';
    }
}

/**
 * 防抖函数
 * @param {Function} func - 要执行的函数
 * @param {number} wait - 等待时间(毫秒)
 * @returns {Function} 防抖后的函数
 */
function debounce(func, wait = 300) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            func.apply(this, args);
        }, wait);
    };
}

/**
 * 获取类型标签HTML
 * @param {string} type - 绑定类型：main, process, thread
 * @returns {string} HTML字符串
 */
function getTypeTagHtml(type) {
    const typeIcons = {
        main: 'layers',
        process: 'select_all',
        thread: 'fiber_manual_record'
    };

    const typeNames = {
        main: '主进程',
        process: '子进程',
        thread: '线程'
    };

    return `
        <div class="binding-type-tag type-${type}">
            <i class="material-icons-round">${typeIcons[type] || 'layers'}</i>
            ${typeNames[type] || '主进程'}
        </div>
    `;
}

/**
 * 格式化错误信息
 * @param {Error|string} error - 错误对象或错误消息
 * @returns {string} 格式化后的错误消息
 */
function formatError(error) {
    if (typeof error === 'string') return error;
    if (error instanceof Error) return error.message;
    return '未知错误';
}

// 存储应用名称到包名的映射
let appNameToPackageMap = new Map();

/**
 * 获取应用列表
 * @param {boolean} forceRefresh - 是否强制刷新，忽略缓存
 * @returns {Promise<{success: boolean, source: string}>} 返回成功状态和数据来源
 */
async function fetchAppList(forceRefresh = false) {
    // 如果是强制刷新，直接使用appinfo工具
    if (forceRefresh) {
        const success = await fetchAppListFromTool();
        return { success, source: 'appinfo' };
    }

    // 尝试读取缓存文件
    const cacheLoaded = await tryLoadFromCache();

    if (cacheLoaded) {
        // 缓存加载成功，启动后台更新
        backgroundUpdateAppList();
        return { success: true, source: '缓存' };
    } else {
        // 无缓存文件，直接使用appinfo工具
        const success = await fetchAppListFromTool();
        return { success, source: 'appinfo' };
    }
}

/**
 * 尝试从缓存文件加载应用列表
 */
async function tryLoadFromCache() {
    try {
        // 检查缓存文件是否存在
        const cacheContent = await execCommand(`
            if [ -f ${CONFIG.APPLIST_CACHE_FILE} ]; then
                cat ${CONFIG.APPLIST_CACHE_FILE}
            else
                echo "not_exists"
            fi
        `);

        if (cacheContent.trim() === 'not_exists' || !cacheContent.trim()) {
            return false;
        }

        // 解析缓存内容（支持异步并行处理）
        const success = await parseCacheContent(cacheContent);
        if (success) {
            return true;
        }

        return false;
    } catch (error) {
        return false; // 缓存读取失败
    }
}

/**
 * 后台更新应用列表
 */
async function backgroundUpdateAppList() {
    try {
        // 延迟执行appinfo工具
        setTimeout(async () => {
            try {
                await fetchAppListFromTool(true);
            } catch (error) {
                // 静默处理错误
            }
        }, 100);
    } catch (error) {
        // 静默处理错误
    }
}

/**
 * 解析缓存文件内容
 */
async function parseCacheContent(content) {
    try {
        appNameToPackageMap.clear();
        const lines = content.split('\n');

        // 过滤出有效行
        const validLines = lines.filter(line => {
            const trimmed = line.trim();
            return trimmed && !trimmed.startsWith('#');
        });

        // 根据数据量选择处理方式
        if (validLines.length < 100) {
            return parseCacheContentSingle(validLines);
        }

        // 使用并行处理
        return await parseCacheContentParallel(validLines);
    } catch (error) {
        return false;
    }
}

/**
 * 单线程解析缓存内容
 */
function parseCacheContentSingle(validLines) {
    try {
        let validCount = 0;

        for (const line of validLines) {
            const trimmedLine = line.trim();

            // 查找逗号分隔符
            const commaIndex = trimmedLine.indexOf(',');
            if (commaIndex === -1) continue;

            // 提取包名和应用名称
            const appName = trimmedLine.substring(0, commaIndex).trim();
            const packageName = trimmedLine.substring(commaIndex + 1).trim();

            // 验证数据有效性
            if (packageName && appName && appName !== '未知应用' && appName !== '') {
                appNameToPackageMap.set(appName, packageName);
                validCount++;
            }
        }

        return validCount > 0;
    } catch (error) {
        return false;
    }
}

/**
 * 并行解析缓存内容
 */
async function parseCacheContentParallel(validLines) {
    try {
        const totalLines = validLines.length;
        const threadCount = 4;
        const chunkSize = Math.ceil(totalLines / threadCount);

        // 创建解析任务
        const parsePromises = [];

        for (let i = 0; i < threadCount; i++) {
            const startIndex = i * chunkSize;
            const endIndex = Math.min(startIndex + chunkSize, totalLines);

            if (startIndex < totalLines) {
                const chunk = validLines.slice(startIndex, endIndex);
                parsePromises.push(parseChunk(chunk, i));
            }
        }

        // 等待所有任务完成
        const results = await Promise.all(parsePromises);

        // 合并解析结果
        let totalValidCount = 0;
        for (const result of results) {
            if (result.success) {
                // 将临时Map合并到主Map
                for (const [appName, packageName] of result.tempMap) {
                    appNameToPackageMap.set(appName, packageName);
                }
                totalValidCount += result.validCount;
            }
        }

        return totalValidCount > 0;
    } catch (error) {
        return false;
    }
}

/**
 * 解析数据块
 * @param {string[]} chunk - 要处理的行数组
 * @param {number} threadId - 线程ID
 * @returns {Promise<{success: boolean, tempMap: Map, validCount: number}>}
 */
async function parseChunk(chunk, threadId) {
    return new Promise((resolve) => {
        try {
            const tempMap = new Map();
            let validCount = 0;

            for (const line of chunk) {
                const trimmedLine = line.trim();

                // 查找逗号分隔符
                const commaIndex = trimmedLine.indexOf(',');
                if (commaIndex === -1) continue;

                // 提取包名和应用名称
                const appName = trimmedLine.substring(0, commaIndex).trim();
                const packageName = trimmedLine.substring(commaIndex + 1).trim();

                // 验证数据有效性
                if (packageName && appName && appName !== '未知应用' && appName !== '') {
                    tempMap.set(appName, packageName);
                    validCount++;
                }
            }

            resolve({
                success: true,
                tempMap: tempMap,
                validCount: validCount
            });
        } catch (error) {
            // 处理错误情况
            resolve({
                success: false,
                tempMap: new Map(),
                validCount: 0
            });
        }
    });
}

/**
 * 使用appinfo工具获取应用信息
 * @param {boolean} silent - 是否静默模式（不显示toast）
 */
async function fetchAppListFromTool(silent = false) {
    try {
        // 检查appinfo工具是否存在并设置权限
        const checkAndSetupResult = await execCommand(`
            if [ -f ${CONFIG.APP_NAME_TOOL} ]; then
                chmod +x ${CONFIG.APP_NAME_TOOL} 2>/dev/null
                echo "ready"
            else
                echo "not_exists"
            fi
        `);

        if (!checkAndSetupResult.includes('ready')) {
            if (!silent) showToast('appinfo工具不存在', 'warning');
            return false;
        }

        // 使用appinfo工具获取应用的包名和应用名称
        const scopeFlag = getAppScopeFlag();
        const command = `${CONFIG.APP_NAME_TOOL} -o pn,an -d "," ${scopeFlag}`;
        const toolResult = await execCommand(command);

        // 检查工具执行结果
        if (!toolResult || toolResult.trim().length === 0) {
            if (!silent) showToast('appinfo工具未返回数据', 'warning');
            return false;
        }

        // 更精确的错误检测 - 只检查明确的错误标识
        const lowerResult = toolResult.toLowerCase();
        const hasError = lowerResult.includes('error:') ||
                        lowerResult.includes('failed:') ||
                        lowerResult.includes('permission denied') ||
                        lowerResult.includes('no such file') ||
                        lowerResult.includes('command not found');

        if (hasError) {
            if (!silent) showToast('appinfo工具执行出错', 'error');
            return false;
        }

        // 检查输出是否包含有效的应用数据
        const lines = toolResult.trim().split('\n');
        const validLines = lines.filter(line => {
            const trimmed = line.trim();
            return trimmed && trimmed.includes(',') && !trimmed.startsWith('#');
        });

        if (validLines.length === 0) {
            if (!silent) showToast('未找到有效的应用数据', 'warning');
            return false;
        }

        // 解析appinfo的输出
        parseAppInfoOutput(toolResult);

        // 静默模式下导出文件
        if (silent) {
            await exportAppListToFile(true);
        }

        return true;

    } catch (error) {
        if (!silent) showToast(`获取应用列表失败: ${error.message || error}`, 'error');
        return false;
    }
}

/**
 * 解析appinfo工具的输出
 * @param {string} output - appinfo工具的输出内容
 */
function parseAppInfoOutput(output) {
    appNameToPackageMap.clear();

    try {
        // 按行分割输出
        const lines = output.trim().split('\n');
        let validCount = 0;

        for (const line of lines) {
            const trimmedLine = line.trim();

            // 跳过空行和注释行
            if (!trimmedLine || trimmedLine.startsWith('#')) continue;

            // 查找逗号分隔符
            const commaIndex = trimmedLine.indexOf(',');
            if (commaIndex === -1) continue;

            // 提取包名和应用名称
            const packageName = trimmedLine.substring(0, commaIndex).trim();
            const appName = trimmedLine.substring(commaIndex + 1).trim();

            // 验证数据有效性
            if (packageName && appName && appName !== '未知应用' && appName !== '') {
                appNameToPackageMap.set(appName, packageName);
                validCount++;
            }
        }

        // 检查解析结果
        if (validCount === 0) {
            showToast('没有解析到任何有效的应用信息', 'warning');
        }

    } catch (error) {
        showToast('解析应用信息失败', 'error');
    }
}

/**
 * 根据应用名称获取包名
 * @param {string} appName - 应用名称
 * @returns {string|null} 包名或null
 */
function getPackageByAppName(appName) {
    return appNameToPackageMap.get(appName) || null;
}

/**
 * 导出应用列表到文件
 * @param {boolean} silent - 是否静默模式（不显示toast）
 */
async function exportAppListToFile(silent = false) {
    try {
        if (!appNameToPackageMap || appNameToPackageMap.size === 0) {
            return;
        }

        // 生成文件内容
        const timestamp = new Date().toLocaleString('zh-CN');
        const scopeFlag = getAppScopeFlag();
        const scopeName = getAppScopeName();

        let content = `# 应用列表导出文件\n`;
        content += `# 导出时间: ${timestamp}\n`;
        content += `# 应用范围: ${scopeName}\n`;
        content += `# 应用数量: ${appNameToPackageMap.size}\n`;
        content += `# 格式: 应用名称,包名\n\n`;

        // 按应用名称排序
        const sortedApps = Array.from(appNameToPackageMap.entries()).sort((a, b) =>
            a[0].localeCompare(b[0], 'zh-CN')
        );

        // 添加应用信息
        for (const [appName, packageName] of sortedApps) {
            content += `${appName},${packageName}\n`;
        }

        // 使用base64编码避免特殊字符问题
        const base64Content = btoa(encodeURIComponent(content).replace(/%([0-9A-F]{2})/g, (match, p1) => String.fromCharCode(parseInt(p1, 16))));

        // 写入文件到webroot目录
        await execCommand(`echo "${base64Content}" | base64 -d > ${CONFIG.APPLIST_CACHE_FILE}`);

    } catch (error) {
        // 静默处理错误，不影响主要功能
    }
}

/**
 * 获取应用范围的中文名称
 * @returns {string} 应用范围名称
 */
function getAppScopeName() {
    const scope = getAppScope();
    return APP_SCOPE_OPTIONS[scope]?.name || '未知范围';
}



/**
 * 获取所有应用名称
 * @returns {Array<string>} 应用名称数组
 */
function getAllAppNames() {
    return Array.from(appNameToPackageMap.keys());
}

/**
 * 获取当前应用范围设置
 * @returns {string} 应用范围 ('user', 'system', 'all')
 */
function getAppScope() {
    return localStorage.getItem(APP_SCOPE_STORAGE_KEY) || 'user';
}

/**
 * 设置应用范围
 * @param {string} scope - 应用范围 ('user', 'system', 'all')
 */
function setAppScope(scope) {
    if (APP_SCOPE_OPTIONS[scope]) {
        localStorage.setItem(APP_SCOPE_STORAGE_KEY, scope);
    }
}

/**
 * 获取当前应用范围的显示名称
 * @returns {string} 显示名称
 */
function getAppScopeName() {
    const scope = getAppScope();
    return APP_SCOPE_OPTIONS[scope]?.name || '用户应用';
}

/**
 * 获取当前应用范围的appinfo命令标志
 * @returns {string} 命令标志
 */
function getAppScopeFlag() {
    const scope = getAppScope();
    return APP_SCOPE_OPTIONS[scope]?.flag || '-3';
}

