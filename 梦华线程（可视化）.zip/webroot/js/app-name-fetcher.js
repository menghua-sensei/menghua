/**
* 高效且可靠的应用名获取器
* 采用多层级回退策略，确保100%成功率
*/
class AppNameFetcher {
constructor() {
this.cache = new Map();
this.packageCache = new Map();
this.methods = [
this.methodPmDumpsys,
this.methodPmList,
this.methodAppInfo,
this.methodAapt,
this.methodManifest
];
}
/**
* 获取应用名称 - 主入口
* @param {string} packageName - 包名
* @param {boolean} useCache - 是否使用缓存
* @returns {Promise<string>} 应用名称
*/
async getAppName(packageName, useCache = true) {
if (!packageName) return '未知应用';
if (useCache && this.cache.has(packageName)) {
return this.cache.get(packageName);
}
for (const method of this.methods) {
try {
const appName = await method.call(this, packageName);
if (appName && appName !== '未知应用') {
this.cache.set(packageName, appName);
return appName;
}
} catch (error) {
console.warn(`方法 ${method.name} 失败:`, error);
continue;
}
}
const fallbackName = this.extractAppNameFromPackage(packageName);
this.cache.set(packageName, fallbackName);
return fallbackName;
}
/**
* 批量获取应用名称
* @param {Array<string>} packageNames - 包名数组
* @param {string} scope - 应用范围 ('user', 'system', 'all')
* @returns {Promise<Map>} 包名到应用名的映射
*/
async batchGetAppNames(packageNames = null, scope = 'user') {
const result = new Map();
try {
if (!packageNames) {
packageNames = await this.getInstalledPackages(scope);
}
const batchResult = await this.batchMethodPmDumpsys(packageNames);
for (const [pkg, name] of batchResult) {
if (name && name !== '未知应用') {
result.set(pkg, name);
this.cache.set(pkg, name);
}
}
const failedPackages = packageNames.filter(pkg => !result.has(pkg));
if (failedPackages.length > 0) {
console.log(`批量处理失败 ${failedPackages.length} 个包，开始单独处理...`);
for (const pkg of failedPackages) {
const name = await this.getAppName(pkg, false);
result.set(pkg, name);
}
}
return result;
} catch (error) {
console.error('批量获取应用名失败:', error);
for (const pkg of packageNames || []) {
const name = await this.getAppName(pkg, false);
result.set(pkg, name);
}
return result;
}
}
/**
* 方法1: 使用 pm dumpsys 获取应用名 (最快，最可靠)
*/
async methodPmDumpsys(packageName) {
const cmd = `dumpsys package "${packageName}" 2>/dev/null | grep -E "(applicationLabel|label)" | head -1`;
const result = await execCommand(cmd);
if (result) {
const patterns = [
/applicationLabel=(.+)/,
/label=(.+)/,
/Application Label: (.+)/i
];
for (const pattern of patterns) {
const match = result.match(pattern);
if (match && match[1]) {
return match[1].trim().replace(/['"]/g, '');
}
}
}
throw new Error('pm dumpsys 未找到应用名');
}
/**
* 方法2: 使用 pm list + pm dump 组合
*/
async methodPmList(packageName) {
const checkCmd = `pm list packages | grep "^package:${packageName}$"`;
const exists = await execCommand(checkCmd);
if (!exists) {
throw new Error('包不存在');
}
const pathCmd = `pm path "${packageName}" 2>/dev/null | head -1`;
const pathResult = await execCommand(pathCmd);
if (pathResult && pathResult.includes('package:')) {
const apkPath = pathResult.replace('package:', '').trim();
return await this.methodAapt(packageName, apkPath);
}
throw new Error('无法获取应用路径');
}
/**
* 方法3: 使用当前的 appinfo 工具 (保持兼容性)
*/
async methodAppInfo(packageName) {
const toolPath = CONFIG.APP_NAME_TOOL;
const checkCmd = `[ -f "${toolPath}" ] && echo "exists"`;
const exists = await execCommand(checkCmd);
if (exists.trim() !== 'exists') {
throw new Error('appinfo工具不存在');
}
await execCommand(`chmod +x "${toolPath}" 2>/dev/null`);
const cmd = `"${toolPath}" -o an -p "${packageName}" 2>/dev/null`;
const result = await execCommand(cmd);
if (result && result.trim() && !result.includes('error')) {
return result.trim();
}
throw new Error('appinfo工具执行失败');
}
/**
* 方法4: 使用 aapt 工具
*/
async methodAapt(packageName, apkPath = null) {
if (!apkPath) {
const pathCmd = `pm path "${packageName}" 2>/dev/null | head -1`;
const pathResult = await execCommand(pathCmd);
if (!pathResult || !pathResult.includes('package:')) {
throw new Error('无法获取APK路径');
}
apkPath = pathResult.replace('package:', '').trim();
}
const aaptCommands = [
`aapt dump badging "${apkPath}" 2>/dev/null | grep -E "application-label:" | head -1`,
`aapt dump xmltree "${apkPath}" AndroidManifest.xml 2>/dev/null | grep -E "android:label" | head -1`
];
for (const cmd of aaptCommands) {
try {
const result = await execCommand(cmd);
if (result) {
const appName = this.parseAaptOutput(result);
if (appName) return appName;
}
} catch (error) {
continue;
}
}
throw new Error('aapt解析失败');
}
/**
* 方法5: 直接解析 AndroidManifest.xml (终极回退)
*/
async methodManifest(packageName) {
const pathCmd = `pm path "${packageName}" 2>/dev/null | head -1`;
const pathResult = await execCommand(pathCmd);
if (!pathResult || !pathResult.includes('package:')) {
throw new Error('无法获取APK路径');
}
const apkPath = pathResult.replace('package:', '').trim();
const tempDir = `/tmp/manifest_${Date.now()}`;
const extractCmd = `mkdir -p "${tempDir}" && unzip -q "${apkPath}" AndroidManifest.xml -d "${tempDir}" 2>/dev/null`;
try {
await execCommand(extractCmd);
const manifestPath = `${tempDir}/AndroidManifest.xml`;
const manifestCmd = `[ -f "${manifestPath}" ] && cat "${manifestPath}"`;
const manifestContent = await execCommand(manifestCmd);
if (manifestContent) {
const labelMatch = manifestContent.match(/android:label="([^"]+)"/);
if (labelMatch && labelMatch[1]) {
return labelMatch[1];
}
}
} finally {
await execCommand(`rm -rf "${tempDir}" 2>/dev/null`);
}
throw new Error('Manifest解析失败');
}
/**
* 批量方法: 使用 pm dumpsys 批量获取
*/
async batchMethodPmDumpsys(packageNames) {
const result = new Map();
const batchCmd = packageNames.map(pkg =>
`echo "PKG:${pkg}" && dumpsys package "${pkg}" 2>/dev/null | grep -E "(applicationLabel|label)" | head -1`
).join(' && ');
try {
const output = await execCommand(batchCmd);
const lines = output.split('\n');
let currentPackage = null;
for (const line of lines) {
const trimmed = line.trim();
if (trimmed.startsWith('PKG:')) {
currentPackage = trimmed.substring(4);
} else if (currentPackage && trimmed) {
const appName = this.parseAppLabel(trimmed);
if (appName) {
result.set(currentPackage, appName);
currentPackage = null;
}
}
}
} catch (error) {
console.warn('批量pm dumpsys失败:', error);
}
return result;
}
/**
* 获取已安装的包列表
*/
async getInstalledPackages(scope = 'user') {
const flags = {
'user': '-3',
'system': '-s',
'all': '-a'
};
const flag = flags[scope] || '-3';
const cmd = `pm list packages ${flag} | cut -d: -f2`;
const result = await execCommand(cmd);
return result ? result.trim().split('\n').filter(pkg => pkg.trim()) : [];
}
/**
* 解析aapt输出
*/
parseAaptOutput(output) {
const patterns = [
/application-label:'([^']+)'/,
/application-label:"([^"]+)"/,
/application-label:([^\s]+)/,
/android:label="([^"]+)"/
];
for (const pattern of patterns) {
const match = output.match(pattern);
if (match && match[1]) {
return match[1].trim();
}
}
return null;
}
/**
* 解析应用标签
*/
parseAppLabel(text) {
const patterns = [
/applicationLabel=(.+)/,
/label=(.+)/,
/Application Label: (.+)/i
];
for (const pattern of patterns) {
const match = text.match(pattern);
if (match && match[1]) {
return match[1].trim().replace(/['"]/g, '');
}
}
return null;
}
/**
* 从包名提取应用名 (最后的回退方案)
*/
extractAppNameFromPackage(packageName) {
if (!packageName) return '未知应用';
const cleanName = packageName
.replace(/^(com|org|net|io|app)\./g, '')
.replace(/\./g, ' ')
.split(' ')
.map(word => word.charAt(0).toUpperCase() + word.slice(1))
.join(' ');
return cleanName || packageName;
}
/**
* 清除缓存
*/
clearCache() {
this.cache.clear();
this.packageCache.clear();
}
/**
* 获取缓存统计
*/
getCacheStats() {
return {
appNameCache: this.cache.size,
packageCache: this.packageCache.size
};
}
}
const appNameFetcher = new AppNameFetcher();